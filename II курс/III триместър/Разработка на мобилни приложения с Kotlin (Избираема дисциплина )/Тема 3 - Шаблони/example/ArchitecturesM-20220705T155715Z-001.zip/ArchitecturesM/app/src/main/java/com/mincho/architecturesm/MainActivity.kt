package com.mincho.architecturesm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.mincho.architecturesm.databinding.ActivityMainBinding
import com.mincho.architecturesm.mvc.MVCActivity
import com.mincho.architecturesm.mvp.MVPActivity
import com.mincho.architecturesm.mvvm.MVVMActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonMVC.setOnClickListener {
            startActivity(MVCActivity.getIntent(this))
        }

        binding.buttonMVP.setOnClickListener {
            startActivity(MVPActivity.getIntent(this))
        }

        binding.buttonMVVM.setOnClickListener {
            startActivity(MVVMActivity.getIntent(this))
        }
    }
}