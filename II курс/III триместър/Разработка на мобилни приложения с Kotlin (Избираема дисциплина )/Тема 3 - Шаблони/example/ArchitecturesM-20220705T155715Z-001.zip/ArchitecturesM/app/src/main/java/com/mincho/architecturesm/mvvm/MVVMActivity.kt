package com.mincho.architecturesm.mvvm

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import com.mincho.architecturesm.R
import com.mincho.architecturesm.databinding.ActivityMvvmBinding
import java.util.ArrayList

class MVVMActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMvvmBinding

    private lateinit var viewModel: CountriesViewModel

    private lateinit var adapter: ArrayAdapter<String>

    private val listValues:MutableList<String>  = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMvvmBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = CountriesViewModel(this.application)

        adapter = ArrayAdapter(this, R.layout.row_layout, R.id.listText, listValues)

        binding.list.adapter = adapter
        binding.list.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            Toast.makeText(
                this,
                "You clicked " + listValues[position],
                Toast.LENGTH_SHORT
            ).show()
        }
        observeViewModel()
    }

    private fun observeViewModel(){
        Log.v("MVVM","observe")
        viewModel.countries.observe(this, {countries ->
            if (countries != null) {
                listValues.clear()
                listValues.addAll(countries)
                binding.retryButton.visibility = View.GONE
                binding.progress.visibility = View.GONE
                binding.list.visibility = View.VISIBLE
                adapter.notifyDataSetChanged()
            } else {
                binding.list.visibility = View.GONE
            }
        })


        viewModel.error.observe(this,{error ->
            if (error != null) {
                Toast.makeText(
                    this,
                    getString(R.string.error_message) + "${error.message}",
                    Toast.LENGTH_LONG
                ).show()
                binding.progress.visibility = View.GONE
                binding.list.visibility = View.GONE
                binding.retryButton.visibility = View.VISIBLE
            } else {
                binding.retryButton.visibility = View.GONE
            }
        })
    }

    fun onRetry(view: View){
        viewModel.onRefresh()
        binding.list.visibility = View.GONE
        binding.retryButton.visibility = View.GONE
        binding.progress.visibility = View.VISIBLE
    }

    companion object{
        fun getIntent( context: Context): Intent {
            return Intent(context,MVVMActivity::class.java)
        }
    }
}