package com.mincho.architecturesm.mvc

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import androidx.appcompat.app.AppCompatActivity
import com.mincho.architecturesm.R
import com.mincho.architecturesm.databinding.ActivityMvcBinding
import java.util.*

class MVCActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMvcBinding

    private val listValues: MutableList<String?> = ArrayList()
    private lateinit var adapter: ArrayAdapter<String>

    private lateinit var controller: CountriesController


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMvcBinding.inflate(layoutInflater)
        setContentView(binding.root)


        title = "MVC Activity"

        controller = CountriesController(this)

        binding.retryButton.setOnClickListener {
            onRetry(it)
        }


        adapter = ArrayAdapter(this, R.layout.row_layout, R.id.listText, listValues)

        binding.list.adapter = adapter
        binding.list.onItemClickListener = OnItemClickListener { _, _, position, _ ->
            Toast.makeText(
                this@MVCActivity,
                "You clicked " + listValues[position],
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun setValues(values: List<String>) {
        listValues.clear()
        listValues.addAll(values)
        binding.retryButton.visibility = View.GONE
        binding.progress.visibility = View.GONE
        binding.list.visibility = View.VISIBLE
        adapter.notifyDataSetChanged()
    }

    fun onRetry(view: View?) {
        controller.onRefresh()
        binding.list.visibility = View.GONE
        binding.retryButton.visibility = View.GONE
        binding.progress.visibility = View.VISIBLE
    }

    fun onError(e: Throwable) {
        Toast.makeText(this, getString(R.string.error_message)+"${e.message}", Toast.LENGTH_LONG).show()
        binding.progress.visibility = View.GONE
        binding.list.visibility = View.GONE
        binding.retryButton.visibility = View.VISIBLE
    }

    companion object {
        fun getIntent(context: Context?): Intent {
            return Intent(context, MVCActivity::class.java)
        }
    }
}