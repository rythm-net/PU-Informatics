package com.mincho.architecturesm.mvp

import com.mincho.architecturesm.model.CountriesService
import com.mincho.architecturesm.model.Country
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers
import java.util.ArrayList

/**
 *Created by Mincho Simov on 27/01/2021.
 */
class CountriesPresenter(private var view: View) {

    private val service: CountriesService = CountriesService()

    interface View{
        fun setValues(values: List<String>)
        fun onError(e: Throwable)
    }

    init {
        fetchCountries()
    }


    private fun fetchCountries() {
        val countries = service.getCountries()
        countries.subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(object : DisposableSingleObserver<List<Country>>() {
                override fun onSuccess(value: List<Country>) {
                    val countryNames: MutableList<String> = ArrayList()
                    for (country in value) {
                        countryNames.add(country.countryName)
                    }
                    view.setValues(countryNames)
                }

                override fun onError(e: Throwable) {
                    view.onError(e)
                }
            })
    }

    fun onRefresh() {fetchCountries()}
}