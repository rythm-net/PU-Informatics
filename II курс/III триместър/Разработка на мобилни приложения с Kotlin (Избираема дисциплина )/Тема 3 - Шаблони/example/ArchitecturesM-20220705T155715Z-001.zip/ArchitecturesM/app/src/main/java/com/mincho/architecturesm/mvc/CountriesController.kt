package com.mincho.architecturesm.mvc

import com.mincho.architecturesm.model.CountriesService
import com.mincho.architecturesm.model.Country
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers
import java.util.*

/**
 *Created by Mincho Simov on 26/01/2021.
 */
class CountriesController(private val view: MVCActivity) {

    private val service: CountriesService = CountriesService()

    init {
        fetchCountries()
    }

    private fun fetchCountries() {
        val countries = service.getCountries()
        countries.subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(object : DisposableSingleObserver<List<Country>>() {
                override fun onSuccess(value: List<Country>) {
                    val countryNames: MutableList<String> = ArrayList()
                    for (country in value) {
                        countryNames.add(country.countryName)
                    }
                    view.setValues(countryNames)
                }

                override fun onError(e: Throwable) {
                    view.onError(e)
                }
            })
    }

    fun onRefresh() {
        fetchCountries()
    }


}
