package com.mincho.architecturesm.mvvm

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.mincho.architecturesm.model.CountriesService
import com.mincho.architecturesm.model.Country
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers
import java.util.ArrayList

/**
 *Created by Mincho Simov on 27/01/2021.
 */
class CountriesViewModel(application: Application) : AndroidViewModel(application){

    private val service: CountriesService = CountriesService()

    private val countriesGet = MutableLiveData<List<String>>()
    val countries: LiveData<List<String>>
        get() = countriesGet

    private val errorGet = MutableLiveData<Throwable?>()
    val error: LiveData<Throwable?>
        get() = errorGet

    init {
        fetchCountries()
    }

    private fun fetchCountries() {
        Log.v("MVVM ", "fetch")
        val countries = service.getCountries()
        countries.subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(object : DisposableSingleObserver<List<Country>>() {
                override fun onSuccess(value: List<Country>) {
                    val countryNames: MutableList<String> = ArrayList()
                    for (country in value) {
                        countryNames.add(country.countryName)
                    }
                    countriesGet.postValue(countryNames)
                    errorGet.postValue(null)
                }

                override fun onError(e: Throwable) {
                    errorGet.postValue(e)
                }
            })
    }

    fun onRefresh(){fetchCountries()}
}