package com.mincho.architecturesm.model

import com.google.gson.annotations.SerializedName

/**
 *Created by Mincho Simov on 26/01/2021.
 */
class Country {
    @SerializedName("name")
    var countryName: String = ""
}
