package com.mincho.architecturesm.model

import io.reactivex.Single
import retrofit2.http.GET

/**
 *Created by Mincho Simov on 26/01/2021.
 */
interface CountriesApi {
    @GET("all")
    fun getCountries(): Single<List<Country>>
}