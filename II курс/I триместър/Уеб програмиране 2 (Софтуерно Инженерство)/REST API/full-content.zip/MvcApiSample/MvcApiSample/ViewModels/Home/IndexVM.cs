﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcApiSample.ViewModels.Home
{
    public class IndexVM
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
