﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReflectionSample.Entities
{
    public class Contact
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string Email { get; set; }

        //private int id;
        //public int get_Id() { return id; }
        //public void set_Id(int value) { id = value; }
    }
}
/*
    Base Class Library
    int - Int32
    long - Int64
    short - Int16
    float - Single
    double - Double
    string - String
    char - Char
    bool - Boolean
    ...
*/
