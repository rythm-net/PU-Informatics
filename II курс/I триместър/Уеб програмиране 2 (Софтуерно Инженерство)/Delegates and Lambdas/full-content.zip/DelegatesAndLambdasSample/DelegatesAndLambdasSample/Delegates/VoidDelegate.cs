﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DelegatesAndLambdasSample.Delegates
{
    public delegate void VoidDelegate();
    public delegate int BinaryOperationDelegate(int a, int b);
}
