﻿using System;

namespace SnakeGame
{
    class Program
    {
        static void Main(string[] args)
        {
            GameEngine gameEngine = new GameEngine();
            gameEngine.Run();
        }
    }
}
