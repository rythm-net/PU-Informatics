﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SnakeGame.Tools
{
    public enum DirectionEnum
    {
        Up,
        Down,
        Left,
        Right
    }
}
