package com.github.hrabur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BullsAndCowsApplicationTests {

  @Test
  void contextLoads() {}
}
