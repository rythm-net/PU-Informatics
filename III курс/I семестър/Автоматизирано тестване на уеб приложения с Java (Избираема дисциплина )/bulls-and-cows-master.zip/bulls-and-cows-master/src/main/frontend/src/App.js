import "./App.css";
import BullsAndCowsGame from "./BullsAndCowsGame";

function App() {
  return (
    <div className="App">
      <h1>Bulls & Cows</h1>
      <h5>No limits edition</h5>
      <BullsAndCowsGame />
    </div>
  );
}

export default App;
