﻿Namespace Draw
	''' <summary>
	''' Потребителски контрол, в който ще се визуализира модела.
	''' Използва се за визуализация с двойно буфериране.
	''' </summary>
	Public Partial Class DoubleBufferedPanel
		Inherits UserControl
		Public Sub New()
			'
			' The InitializeComponent() call is required for Windows Forms designer support.
			'
			InitializeComponent()

			'
			' TODO: Add constructor code after the InitializeComponent() call.
			'
		End Sub
	End Class
End Namespace
