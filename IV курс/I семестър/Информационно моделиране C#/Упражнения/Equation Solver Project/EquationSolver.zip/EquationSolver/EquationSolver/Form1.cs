﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;


namespace EquationSolver
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double SolveExpression (String expression){

            if (expression.StartsWith("("))
            {
                int opening_brackets = 1;
                int closing_brackets = 0;
                int current_symbol = 1;

                while (opening_brackets != closing_brackets)
                {
                    if (expression[current_symbol] == '(')
                        opening_brackets++;
                    else if (expression[current_symbol] == ')')
                        closing_brackets++;

                    current_symbol++;
                }

                String expr = expression.Substring(1, current_symbol - 2);
                expression = expression.Remove(0, current_symbol);

                Match operation = Regex.Match(expression, @"^[\+\-\*\/]");

                if (operation.Success)
                {
                    expression = expression.Remove(0, operation.Value.Length);
                    switch (operation.Value)
                    {
                        case "+":
                            {
                                return SolveExpression(expr) + SolveExpression(expression);
                            }
                        case "-":
                            {
                                return SolveExpression(expr) - SolveExpression(expression);
                            }
                        case "*":
                            {
                                return SolveExpression(expr) * SolveExpression(expression);
                            }
                        case "/":
                            {
                                return SolveExpression(expr) / SolveExpression(expression);
                            }
                    }

                }

                else
                    return SolveExpression(expr);
            }

            Match constant = Regex.Match(expression, @"^[0-9]+");
            if (constant.Success)
            {
                expression = expression.Remove(0, constant.Value.Length);

                Match operation = Regex.Match(expression, @"^[\+\-\*\/]");
                if (operation.Success)
                {
                    expression = expression.Remove(0, operation.Value.Length);
                    switch (operation.Value)
                    {
                        case "+":
                            {

                                return Double.Parse(constant.Value) + SolveExpression(expression);
                            }

                        case "-":
                            {

                                return Double.Parse(constant.Value) - SolveExpression(expression);
                            }
                        case "*":
                            {

                                return Double.Parse(constant.Value) * SolveExpression(expression);
                            }
                        case "/":
                            {

                                return Double.Parse(constant.Value) / SolveExpression(expression);
                            }
                    }
                }

                else
                    return Double.Parse(constant.Value);
            }

            else throw new Exception("Invalid Expresson");
            return 0;
        }

        private Dictionary<String, Double> CreateVariablesList()
        {
            Dictionary<String, Double> variables = new Dictionary<String, Double>();

            foreach (String line in this.tbEquation.Lines)
            {
                String currentLine = line.Replace(" ","");
                if (currentLine.Contains("'="))
                    continue;

                String variableName = currentLine.Substring(0, currentLine.IndexOf("="));
                String variableExpression = currentLine.Substring(currentLine.IndexOf("=")+1);

                foreach (KeyValuePair<String, Double> variable in variables)
                    variableExpression = variableExpression.Replace(variable.Key, variable.Value.ToString());

                variables.Add(variableName, SolveExpression(variableExpression));
            }

            return variables;
        }

        private Dictionary<string, string> CreateDerivativesList()
        {
            Dictionary<string, string> derivatives = new Dictionary<string, string>();

            foreach (string line in tbEquation.Lines)
            {
                String currentLine = line.Replace(" ", "");
                if (!currentLine.Contains("'="))
                    continue;

                String derivativeName = currentLine.Substring(0, currentLine.IndexOf("'"));
                String derivativeExpression = currentLine.Substring(currentLine.IndexOf("'=") + 2);

                derivatives.Add(derivativeName, derivativeExpression);
            }

            return derivatives;
        }

        private Dictionary<string, List<double>> RunSimulation()
        {
            int time = Int32.Parse(txtTime.Text);
            int step = Int32.Parse(txtStep.Text);

            Dictionary<string, List<double>> variableHistory = new Dictionary<string, List<double>>();

            Dictionary<String, Double> variables = CreateVariablesList();
            Dictionary<string, string> derivatives = CreateDerivativesList();

            foreach (var variable in variables)
            {
                variableHistory.Add(variable.Key, new List<double>());
                variableHistory[variable.Key].Add(variable.Value);
            }

            for (int i = step; i < time; i += step)
            {
                foreach (var derivative in derivatives)
                {
                    string expression = derivative.Value;
                    foreach (var variableName in variables)
                    {
                        expression = expression.Replace(variableName.Key, variableName.Value.ToString());
                        expression = expression.Replace("STEP", step.ToString());
                    }

                    //double nextValue = variables[derivative.Key] + step * SolveExpression(expression);
                    double nextValue = variables[derivative.Key] + SolveExpression(expression);
                    variableHistory[derivative.Key].Add(nextValue);
                }
            }

            return variableHistory;
        }

        private void DrawGraphics(Graphics g, Dictionary<string, List<double>> historyResult)
        {
            foreach (var result in historyResult)
            {
                Pen pen = new Pen(Color.Green);
                for (int i = 0; i < result.Value.Count - 1; i++)
                {
                    g.DrawLine(pen, (float)i, (float)result.Value[i], (float)(i + 1), (float)result.Value[i + 1]);
                }
            }
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            Dictionary<String, Double> variables = CreateVariablesList();
            Dictionary<string, string> derivatives = CreateDerivativesList();
            foreach (KeyValuePair<String, Double> var in variables)
                lbResultsA.Items.Add(var.Key + "= " + var.Value);

            foreach (var derivative in derivatives)
                lbResultsA.Items.Add(String.Format("{0}= {1}", derivative.Key, derivative.Value));

            //Попълнете lbResultsA със стойностите на A
            //Попълнете lbResultsB със стойностите на B

            //Изчертава графиката
            Dictionary<string, List<double>> results = RunSimulation();
            DrawGraphics(pbDraw.CreateGraphics(), results);
        }
    }
}
