﻿namespace EquationSolver
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbEquation = new System.Windows.Forms.TextBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.lbResultsA = new System.Windows.Forms.ListBox();
            this.lbResultADerivative = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtStep = new System.Windows.Forms.TextBox();
            this.pbDraw = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbDraw)).BeginInit();
            this.SuspendLayout();
            // 
            // tbEquation
            // 
            this.tbEquation.Location = new System.Drawing.Point(12, 12);
            this.tbEquation.Multiline = true;
            this.tbEquation.Name = "tbEquation";
            this.tbEquation.Size = new System.Drawing.Size(159, 172);
            this.tbEquation.TabIndex = 0;
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(19, 332);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(152, 45);
            this.btnRun.TabIndex = 1;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // lbResultsA
            // 
            this.lbResultsA.FormattingEnabled = true;
            this.lbResultsA.Location = new System.Drawing.Point(599, 12);
            this.lbResultsA.Name = "lbResultsA";
            this.lbResultsA.Size = new System.Drawing.Size(187, 173);
            this.lbResultsA.TabIndex = 2;
            // 
            // lbResultADerivative
            // 
            this.lbResultADerivative.FormattingEnabled = true;
            this.lbResultADerivative.Location = new System.Drawing.Point(599, 204);
            this.lbResultADerivative.Name = "lbResultADerivative";
            this.lbResultADerivative.Size = new System.Drawing.Size(187, 173);
            this.lbResultADerivative.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 207);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Time";
            // 
            // txtTime
            // 
            this.txtTime.Location = new System.Drawing.Point(54, 204);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(100, 20);
            this.txtTime.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 237);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Step";
            // 
            // txtStep
            // 
            this.txtStep.Location = new System.Drawing.Point(54, 234);
            this.txtStep.Name = "txtStep";
            this.txtStep.Size = new System.Drawing.Size(100, 20);
            this.txtStep.TabIndex = 7;
            // 
            // pbDraw
            // 
            this.pbDraw.Location = new System.Drawing.Point(187, 12);
            this.pbDraw.Name = "pbDraw";
            this.pbDraw.Size = new System.Drawing.Size(406, 365);
            this.pbDraw.TabIndex = 8;
            this.pbDraw.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(798, 392);
            this.Controls.Add(this.pbDraw);
            this.Controls.Add(this.txtStep);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbResultADerivative);
            this.Controls.Add(this.lbResultsA);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.tbEquation);
            this.Name = "Form1";
            this.Text = "EquationSolver";
            ((System.ComponentModel.ISupportInitialize)(this.pbDraw)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbEquation;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.ListBox lbResultsA;
        private System.Windows.Forms.ListBox lbResultADerivative;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtStep;
        private System.Windows.Forms.PictureBox pbDraw;
    }
}

