const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

window.addEventListener("load", (event) => {
    refresh()
  });

async function registerNewUser (fields) {
	const response = await fetch(`http://localhost:8080/api/v1/user/register`, {
		method: 'post',
		headers: { 'Content-Type': 'application/json'},
		body: JSON.stringify(fields)
	})

	let result = await response.json()
    sessionStorage.setItem("token", result.access_token)
    refresh()
}
async function login (fields) {
	const response = await fetch(`http://localhost:8080/api/v1/user/login`, {
		method: 'post',
		headers: { 'Content-Type': 'application/json'},
		body: JSON.stringify(fields)
	})

	let result = await response.json()
    if (result != undefined){
        sessionStorage.setItem("token", result.access_token)
        refresh()
    }
    
}

signUpButton.addEventListener('click', () => {
	container.classList.add("right-panel-active");
});

signInButton.addEventListener('click', () => {
	container.classList.remove("right-panel-active");
});


document.getElementById('register-form').addEventListener('submit', async (e) => {
	e.preventDefault()
    const formData = new FormData(e.target)
    const fields = Object.fromEntries([...formData.entries()])
    registerNewUser(fields)
})

document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault()
    const formData = new FormData(e.target)
    const fields = Object.fromEntries([...formData.entries()])
    login(fields)
})

function refresh(){
    if (sessionStorage.getItem("token") != undefined){
        window.location.href = "http://127.0.0.1:5500/index.html";
    }
}




