window.addEventListener("load", (event) => {
    refresh()
    addData()
  });

async function allUserPases() {
	const response = await fetch(`http://localhost:8080/api/v1/paste/byUser`, {
		method: 'GET',
		headers: { 'Content-Type': 'application/json',
                    'Authorization': `Bearer ${sessionStorage.getItem("token")}`                
    },
	})

	let result = await response.json()
    console.log(result)
}
var elements = document. querySelector(".logoutBtn").addEventListener("click", () =>{
    sessionStorage.removeItem("token")
refresh()
});

function refresh(){
    if (sessionStorage.getItem("token") == undefined){
        window.location.href = "http://127.0.0.1:5500/login.html";
    }
}

async function addData(){
    let dataToAdd = "";
    const allPastes = await allUserPases();
    for (let i = 0; i < allPastes.length; i++) {
        dataToAdd += `
        <li>
        <strong>${allPastes[i].title}</strong>
        <p>${allPastes[i].content}</p>
        </li>`
    }

    let orderredList = document.querySelector(".alternating-colors")
   console.log(orderredList)
}
