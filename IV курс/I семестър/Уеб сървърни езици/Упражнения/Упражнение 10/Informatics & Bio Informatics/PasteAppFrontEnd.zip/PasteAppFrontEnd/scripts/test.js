async function allUserPases() {
	const response = await fetch(`http://localhost:8080/api/v1/paste/byUser`, {
		method: 'GET',
		headers: { 'Content-Type': 'application/json',
                    'Authorization': `Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ4RW1yMyIsImlhdCI6MTcwMTkyOTk4NiwiZXhwIjoxNzAxOTMzNTg2fQ.S2Q4shnQYAoIPb9DTsBpwozLgboygrgUU3uKaKygPgY`                
    },
	})

	let result = await response.json()
    return result;
}

async function addData(){
    let dataToAdd = "";
    const allPastes = await allUserPases();
    for (let i = 0; i < allPastes.length; i++) {
        dataToAdd += `
        <li>
        <strong>${allPastes[i].title}</strong>
        <p>${allPastes[i].content}</p>
        </li>`
    }
    //document.querySelector(".alternating-colors").innerHTML = dataToAdd;
}


addData()
