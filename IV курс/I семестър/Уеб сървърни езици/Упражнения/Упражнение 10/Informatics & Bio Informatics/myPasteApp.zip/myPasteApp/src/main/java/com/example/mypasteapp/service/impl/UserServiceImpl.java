package com.example.mypasteapp.service.impl;

import com.example.mypasteapp.config.JWT.JwtService;
import com.example.mypasteapp.dao.MyPasteRepository;
import com.example.mypasteapp.dao.UserRepository;
import com.example.mypasteapp.model.DTO.UserDTO;
import com.example.mypasteapp.model.DTO.requests.UpdateUserRequest;
import com.example.mypasteapp.model.DTO.requests.UserRequest;
import com.example.mypasteapp.model.DTO.responses.AuthenticationResponse;
import com.example.mypasteapp.model.DTO.responses.UserDetailedResponse;
import com.example.mypasteapp.model.DTO.responses.UserResponse;
import com.example.mypasteapp.model.MyPaste;
import com.example.mypasteapp.model.User;
import com.example.mypasteapp.service.UserService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final MyPasteRepository myPasteRepository;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository, MyPasteRepository myPasteRepository, AuthenticationManager authenticationManager, JwtService jwtService, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.myPasteRepository = myPasteRepository;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDTO findUserByUsername(String username) {
        User user = userRepository.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException("Invalid user"));
        return new UserDTO(user.getId(), user.getUsername(), user.getEmail(), user.getAge(), user.getFavorites());
    }

    @Override
    public User findUserEntityById(int id) {
        return userRepository.findById(id).get();
    }

    @Override
    public UserDetailedResponse findUserById(int id) {
        return this.userToUserDetailedResponseMapper(this.findUserEntityById(id));
    }

    @Override
    public List<UserResponse> findAllUsers() {
        return userRepository.findAll().stream().map(this::userToUserResponseMapper).toList();
    }

    @Override
    public UserResponse updateUser(int userId, UpdateUserRequest updateUserRequest) {
        User user = this.findUserEntityById(userId);
        User updatedUserInDB = this.updateUserInDB(user, updateUserRequest);
        return this.userToUserResponseMapper(updatedUserInDB);
    }

    @Override
    public void deleteUserById(int userId) {
        userRepository.deleteById(userId);
    }

    @Override
    public void saveUserFavorite(int userId, UUID pasteId) {
        User user = this.findUserEntityById(userId);
        MyPaste paste = myPasteRepository.findById(pasteId).get();
        user.getFavorites().add(paste);
        userRepository.save(user);
    }

    @Override
    public AuthenticationResponse register(String username, String password) {
       User savedUser = userRepository.save(new User(username,  passwordEncoder.encode(password)));
       return this.login(savedUser.getUsername(), password);
    }

    @Override
    public AuthenticationResponse login(String username, String password) {
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
        if(authentication.isAuthenticated()){
            return new AuthenticationResponse(jwtService.GenerateToken(username));
        } else {
            throw new UsernameNotFoundException("invalid user request..!!");
        }
    }



    private User userRequestToUser(UserRequest userRequest){
        return new User(userRequest.getUsername(), userRequest.getPassword());
    }

    private UserResponse userToUserResponseMapper(User user){
        return new UserResponse(user.getId(), user.getUsername(), user.getEmail(), user.getAge());
    }
    private UserDetailedResponse userToUserDetailedResponseMapper(User user){
        List<MyPaste> favs = user.getFavorites();
        return new UserDetailedResponse(user.getId(), user.getUsername(), user.getEmail(), user.getAge(), user.getFavorites().stream().map(MyPasteServiceImpl::myPasteToMyPasteResponseMapperStatic).toList());
    }

    private User updateUserInDB(User user, UpdateUserRequest updateUserRequest){
        user.setUsername(updateUserRequest.getUsername());
        user.setEmail(updateUserRequest.getEmail());
        user.setAge(updateUserRequest.getAge());
        return userRepository.save(user);
    }
}
