package com.example.mypasteapp.service.impl;

import com.example.mypasteapp.dao.CommentRepository;
import com.example.mypasteapp.dao.MyPasteRepository;
import com.example.mypasteapp.dao.UserRepository;
import com.example.mypasteapp.model.Comment;
import com.example.mypasteapp.model.DTO.requests.CommentRequest;
import com.example.mypasteapp.model.DTO.requests.UpdateCommentRequest;
import com.example.mypasteapp.model.DTO.responses.CommentResponse;
import com.example.mypasteapp.model.MyPaste;
import com.example.mypasteapp.model.User;
import com.example.mypasteapp.service.CommentService;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class CommentServiceImpl implements CommentService {

    private final CommentRepository commentRepository;
    private final UserRepository userRepository;

    private final MyPasteRepository myPasteRepository;

    public CommentServiceImpl(CommentRepository commentRepository, UserRepository userRepository, MyPasteRepository myPasteRepository) {
        this.commentRepository = commentRepository;
        this.userRepository = userRepository;
        this.myPasteRepository = myPasteRepository;
    }

    @Override
    public void addCommentToPaste(UUID pasteId, int userId, CommentRequest commentRequest) {
        MyPaste myPaste = myPasteRepository.findById(pasteId).get();
        User user = userRepository.findById(userId).get();
        Comment commentToSave = this.commentRequestToComment(commentRequest);
        commentToSave.setAuthor(user);
        myPaste.getComments().add(commentToSave);
        myPasteRepository.save(myPaste);
    }

    @Override
    public void deleteComment(int id) {
        commentRepository.deleteById(id);
    }

    @Override
    public CommentResponse updateComment(int commentId, UpdateCommentRequest updateCommentRequest) {
        Comment comment = commentRepository.findById(commentId).get();
        comment.setContent(updateCommentRequest.getContent());
        Comment savedComment = commentRepository.save(comment);
        return commentToCommentResponse(savedComment);
    }

    private Comment commentRequestToComment(CommentRequest commentRequest){
       Comment comment = new Comment();
       comment.setContent(commentRequest.getContent());
       return comment;
    }

    private CommentResponse commentToCommentResponse(Comment comment){
        return new CommentResponse(comment.getId(), comment.getContent(), comment.getCreatedOn(), comment.getAuthor().getId());
    }
}
