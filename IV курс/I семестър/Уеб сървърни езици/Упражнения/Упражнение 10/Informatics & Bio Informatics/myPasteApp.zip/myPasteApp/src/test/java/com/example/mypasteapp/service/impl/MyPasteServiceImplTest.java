package com.example.mypasteapp.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.mypasteapp.dao.MyPasteRepository;
import com.example.mypasteapp.model.MyPaste;
import com.example.mypasteapp.model.User;
import com.example.mypasteapp.model.DTO.requests.MyPasteRequest;
import com.example.mypasteapp.service.UserService;

@ExtendWith(MockitoExtension.class)
public class MyPasteServiceImplTest {

	@Mock
	private MyPasteRepository myPasteRepository;

	@Mock
	private UserService userService;

	@Captor
	ArgumentCaptor<MyPaste> pasteCaptor;

	@InjectMocks
	@Spy
	private MyPasteServiceImpl myPasteServiceImpl;

	@Test
	public void saveNewPasteTest() {
		MyPasteRequest request = new MyPasteRequest("Test paste", "Test");
		when(userService.findUserEntityById(1)).thenReturn(new User("test_user", "password"));
		myPasteServiceImpl.saveNewPaste(1, request);
		verify(myPasteRepository, times(1)).save(Mockito.any(MyPaste.class));
		verify(myPasteServiceImpl, times(1)).myPasteRequestToMyPasteMapper(request);
		verify(myPasteRepository).save(pasteCaptor.capture());

		MyPaste actual = pasteCaptor.getValue();
		MyPaste expected = new MyPaste("Test paste", "Test");
		assertThat(actual).usingRecursiveComparison().comparingOnlyFields("title", "content").isEqualTo(expected);
	}

	@Test
	public void getAllPastesTest() {
		User user = new User("user1", "pass");
		List<MyPaste> pasteList = new ArrayList<MyPaste>();
		pasteList.add(new MyPaste("paste 1", "content 1"));
		pasteList.add(new MyPaste("paste 2", "content 2"));
		pasteList.add(new MyPaste("paste 3", "content 3"));
		pasteList.forEach(paste -> paste.setUser(user));
		when(myPasteRepository.findAll()).thenReturn(pasteList);

		myPasteServiceImpl.getAllPastes();

		verify(myPasteServiceImpl, times(3)).myPasteToMyPasteResponseMapper(Mockito.any(MyPaste.class));
	}
}
