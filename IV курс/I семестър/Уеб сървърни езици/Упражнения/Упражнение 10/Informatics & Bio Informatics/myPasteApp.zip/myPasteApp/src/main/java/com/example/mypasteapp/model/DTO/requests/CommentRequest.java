package com.example.mypasteapp.model.DTO.requests;

import com.example.mypasteapp.model.User;

public class CommentRequest {
    private String content;

    public CommentRequest(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
