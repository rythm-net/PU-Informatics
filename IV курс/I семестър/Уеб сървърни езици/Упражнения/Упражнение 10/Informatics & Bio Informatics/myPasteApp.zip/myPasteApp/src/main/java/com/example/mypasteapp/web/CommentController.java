package com.example.mypasteapp.web;

import com.example.mypasteapp.model.DTO.requests.CommentRequest;
import com.example.mypasteapp.model.DTO.requests.UpdateCommentRequest;
import com.example.mypasteapp.model.DTO.responses.CommentResponse;
import com.example.mypasteapp.model.User;
import com.example.mypasteapp.service.CommentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/comment")
public class CommentController {

    private CommentService commentService;

    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @PostMapping()
    public ResponseEntity<Object> addCommentToPaste(@RequestParam UUID pasteId,
                                                    @RequestBody CommentRequest commentRequest,
                                                    @AuthenticationPrincipal User user) {
        commentService.addCommentToPaste(pasteId, user.getId(), commentRequest);
        return new ResponseEntity<>("comment added successfully!", HttpStatus.OK);
    }

    @PutMapping("/{commentId}")
    public ResponseEntity<CommentResponse> updateComment(@PathVariable int commentId,
                                                         @RequestBody UpdateCommentRequest updateCommentRequest) {
        return new ResponseEntity<>(commentService.updateComment(commentId, updateCommentRequest), HttpStatus.OK);
    }

    @DeleteMapping("/{commentId}")
    public ResponseEntity<Object> deleteComment(@PathVariable int commentId) {
        commentService.deleteComment(commentId);
        return new ResponseEntity<>("successfully deleted comment with id: " + commentId, HttpStatus.OK);
    }
}
