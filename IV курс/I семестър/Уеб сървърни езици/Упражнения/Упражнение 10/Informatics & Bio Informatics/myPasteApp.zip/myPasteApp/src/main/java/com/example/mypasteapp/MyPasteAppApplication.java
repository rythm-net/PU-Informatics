package com.example.mypasteapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyPasteAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyPasteAppApplication.class, args);
    }

}
