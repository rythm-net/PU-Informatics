package com.example.mypasteapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyPasteAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
