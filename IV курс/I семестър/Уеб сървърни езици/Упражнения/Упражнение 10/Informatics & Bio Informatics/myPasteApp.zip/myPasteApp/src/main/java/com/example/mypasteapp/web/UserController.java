package com.example.mypasteapp.web;

import com.example.mypasteapp.model.DTO.requests.UpdateUserRequest;
import com.example.mypasteapp.model.DTO.requests.UserRequest;
import com.example.mypasteapp.model.DTO.responses.AuthenticationResponse;
import com.example.mypasteapp.model.DTO.responses.UserDetailedResponse;
import com.example.mypasteapp.model.DTO.responses.UserResponse;
import com.example.mypasteapp.model.User;
import com.example.mypasteapp.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    //Auth

    @CrossOrigin
    @PostMapping(value = "/register", consumes = {"application/json"})
    public ResponseEntity<Object> register(@RequestBody UserRequest userRequest) {
        AuthenticationResponse response = userService.register(userRequest.getUsername(), userRequest.getPassword());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @CrossOrigin
    @PostMapping("/login")
    public ResponseEntity<AuthenticationResponse> login(@RequestBody UserRequest userRequest) {
        AuthenticationResponse response = userService.login(userRequest.getUsername(), userRequest.getPassword());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    //CRUD

    @GetMapping("/details")
    public ResponseEntity<UserDetailedResponse> getUserById(@AuthenticationPrincipal User user) {
        return new ResponseEntity<>(userService.findUserById(user.getId()), HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        return new ResponseEntity<>(userService.findAllUsers(), HttpStatus.OK);
    }

    @PutMapping("")
    public ResponseEntity<UserResponse> updateUser(@AuthenticationPrincipal User user,
                                                   @RequestBody UpdateUserRequest updateUserRequest) {
        return new ResponseEntity<>(userService.updateUser(user.getId(), updateUserRequest), HttpStatus.OK);
    }

    @PostMapping("/favorite")
    public ResponseEntity<Object> saveUserFavorite(@AuthenticationPrincipal User user, @RequestParam UUID pasteId){
        userService.saveUserFavorite(user.getId(), pasteId);
        return new ResponseEntity<>("successfully added paste to user with id " + user.getId(), HttpStatus.OK);
    }

    @DeleteMapping()
    public ResponseEntity<Object> deleteUserById(@AuthenticationPrincipal User user) {
        userService.deleteUserById(user.getId());
        return new ResponseEntity<>("user with id " + user.getId() + "is deleted successfully!", HttpStatus.OK);
    }
}
