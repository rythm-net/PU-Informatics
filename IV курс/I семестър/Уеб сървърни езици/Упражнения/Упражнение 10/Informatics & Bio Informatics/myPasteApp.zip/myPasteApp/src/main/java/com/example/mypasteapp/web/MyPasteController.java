package com.example.mypasteapp.web;

import com.example.mypasteapp.model.DTO.requests.MyPasteRequest;
import com.example.mypasteapp.model.DTO.requests.UpdateMyPasteRequest;
import com.example.mypasteapp.model.DTO.responses.MyPasteResponse;
import com.example.mypasteapp.model.User;
import com.example.mypasteapp.service.MyPasteService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RequestMapping("/api/v1/paste")
@RestController
public class MyPasteController {
    private final MyPasteService myPasteService;

    public MyPasteController(MyPasteService myPasteService) {
        this.myPasteService = myPasteService;
    }

    @PostMapping()
    public ResponseEntity<Object> saveNewPaste(@AuthenticationPrincipal User user,
                                               @RequestBody MyPasteRequest myPasteRequest){
        myPasteService.saveNewPaste(user.getId(), myPasteRequest);
        return new ResponseEntity<>("saved successfully!", HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MyPasteResponse> updatePaste(@RequestBody UpdateMyPasteRequest updateUserRequest,
                                                       @PathVariable UUID id) {
        return new ResponseEntity<>(myPasteService.updatePaste(id, updateUserRequest), HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<List<MyPasteResponse>> allPastes(@AuthenticationPrincipal User user) {
        return new ResponseEntity<>(myPasteService.getAllPastes(), HttpStatus.OK);
    }

    @CrossOrigin
    @GetMapping("/byUser")
    public ResponseEntity<List<MyPasteResponse>> getAllPastesByUserId(@AuthenticationPrincipal User user) {
        return new ResponseEntity<>(myPasteService.getAllPastesByUserId(user.getId()), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteUserById(@PathVariable UUID id) {
        myPasteService.deletePasteById(id);
        return new ResponseEntity<>("user with id " + id + "is deleted successfully!", HttpStatus.OK);
    }
}
