package com.example.mypasteapp.model.DTO.requests;

public class UpdateCommentRequest {
    private String content;

    public UpdateCommentRequest(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
