package com.example.mypasteapp.model.DTO.responses;

import com.example.mypasteapp.model.User;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import org.hibernate.annotations.CreationTimestamp;

import java.time.Instant;

public class CommentResponse {
    private int id;
    private String content;
    private Instant createdOn;
    private int userId;


    public CommentResponse(int id, String content, Instant createdOn, int userId) {
        this.id = id;
        this.content = content;
        this.createdOn = createdOn;
        this.userId = userId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Instant getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Instant createdOn) {
        this.createdOn = createdOn;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
